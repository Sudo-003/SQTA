"""
conftest.py — Shared Pytest fixtures for NovaTech Automated Test Suite
"""

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager


BASE_URL = "https://novatech-premium.netlify.app"


@pytest.fixture(scope="function")
def driver():
    """Create a Chrome WebDriver instance for each test."""
    chrome_options = Options()
    chrome_options.add_argument("--start-maximized")
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--disable-popup-blocking")
    # Uncomment the line below to run in headless mode (no browser window)
    # chrome_options.add_argument("--headless=new")

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.implicitly_wait(10)

    yield driver

    driver.quit()


@pytest.fixture(scope="function")
def clear_cart(driver):
    """Navigate to the site and clear localStorage cart before test."""
    driver.get(BASE_URL)
    driver.execute_script("localStorage.removeItem('luxe_cart');")
    driver.refresh()
    return driver
