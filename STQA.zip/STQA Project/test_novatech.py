"""
============================================================
NovaTech E-Commerce Website — 50 Automated Test Cases
============================================================
Framework: Selenium WebDriver + Pytest
Language: Python
Website: https://novatech-premium.netlify.app/
Author: Nirav
Date: 25-Sep-2026
============================================================

Test Case Categories:
  ATC-001 to ATC-010 : Homepage & Navigation (10)
  ATC-011 to ATC-018 : Product Listing & Filtering (8)
  ATC-019 to ATC-024 : Product Search (6)
  ATC-025 to ATC-029 : Product Details (5)
  ATC-030 to ATC-037 : Shopping Cart (8)
  ATC-038 to ATC-043 : Contact Form (6)
  ATC-044 to ATC-046 : Newsletter Subscription (3)
  ATC-047 to ATC-050 : Responsive Design, UI & SEO (4)
============================================================

HOW TO RUN:
  1. pip install -r requirements.txt
  2. pytest test_novatech.py -v --html=test_report.html --self-contained-html
============================================================
"""

import time
# pyrefly: ignore [missing-import]
import pytest
# pyrefly: ignore [missing-import]
from selenium.webdriver.common.by import By
# pyrefly: ignore [missing-import]
from selenium.webdriver.common.keys import Keys
# pyrefly: ignore [missing-import]
from selenium.webdriver.support.ui import WebDriverWait, Select
# pyrefly: ignore [missing-import]
from selenium.webdriver.support import expected_conditions as EC


BASE_URL = "https://novatech-premium.netlify.app"


# ─── Helper Functions ──────────────────────────────────────

def wait_for_page_load(driver, timeout=10):
    """Wait for the page loader to disappear."""
    try:
        WebDriverWait(driver, timeout).until(
            EC.invisibility_of_element_located((By.ID, "pageLoader"))
        )
    except Exception:
        pass  # Loader may have already been removed
    time.sleep(0.5)


def add_product_to_cart_via_js(driver, product_id=1):
    """Add a product to cart using JavaScript (CartManager)."""
    driver.execute_script(f"""
        const product = ProductData.find(p => p.id === {product_id});
        if (product) CartManager.addItem(product);
    """)
    time.sleep(0.5)


# ═══════════════════════════════════════════════════════════
# ATC-001 to ATC-010: HOMEPAGE & NAVIGATION
# ═══════════════════════════════════════════════════════════

class TestHomepageNavigation:
    """ATC-001 to ATC-010: Homepage & Navigation Tests"""

    # ATC-001: Verify homepage loads successfully
    def test_atc001_homepage_loads(self, driver):
        """ATC-001: Verify homepage loads with all major sections visible."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        assert "NovaTech" in driver.title, "Page title should contain 'NovaTech'"

        # Check key sections exist
        hero = driver.find_element(By.ID, "hero")
        assert hero.is_displayed(), "Hero section should be visible"

        categories = driver.find_element(By.ID, "categories")
        assert categories is not None, "Categories section should exist"

        featured = driver.find_element(By.ID, "featuredProducts")
        assert featured is not None, "Featured products section should exist"

    # ATC-002: Verify NovaTech logo redirects to homepage
    def test_atc002_logo_redirects_home(self, driver):
        """ATC-002: Clicking the logo should navigate to the homepage."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)

        logo = driver.find_element(By.CSS_SELECTOR, "a.nav-logo")
        logo.click()
        wait_for_page_load(driver)

        current_url = driver.current_url.rstrip("/")
        assert current_url == BASE_URL or current_url.endswith("/"), \
            f"Logo should redirect to homepage, got: {current_url}"

    # ATC-003: Verify Products navigation link
    def test_atc003_nav_link_products(self, driver):
        """ATC-003: Products nav link should navigate to /products."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        products_link = driver.find_element(By.CSS_SELECTOR, ".nav-links a[href='/products']")
        products_link.click()
        wait_for_page_load(driver)

        assert "products" in driver.current_url.lower(), \
            "Should navigate to products page"

    # ATC-004: Verify About navigation link
    def test_atc004_nav_link_about(self, driver):
        """ATC-004: About nav link should navigate to /about."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        about_link = driver.find_element(By.CSS_SELECTOR, ".nav-links a[href='/about']")
        about_link.click()
        wait_for_page_load(driver)

        assert "about" in driver.current_url.lower(), \
            "Should navigate to about page"

    # ATC-005: Verify Contact navigation link
    def test_atc005_nav_link_contact(self, driver):
        """ATC-005: Contact nav link should navigate to /contact."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        contact_link = driver.find_element(By.CSS_SELECTOR, ".nav-links a[href='/contact']")
        contact_link.click()
        wait_for_page_load(driver)

        assert "contact" in driver.current_url.lower(), \
            "Should navigate to contact page"

    # ATC-006: Verify active nav link highlighting
    def test_atc006_active_nav_link(self, driver):
        """ATC-006: Current page's nav link should have 'active' class."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        home_link = driver.find_element(By.CSS_SELECTOR, ".nav-links a.active")
        assert home_link.get_attribute("href").endswith("/"), \
            "Home link should be active on homepage"

    # ATC-007: Verify hero section content
    def test_atc007_hero_section_content(self, driver):
        """ATC-007: Hero section should display badge, heading, buttons."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        badge = driver.find_element(By.CSS_SELECTOR, ".hero-badge")
        assert "2024" in badge.text, "Hero badge should mention '2024'"

        heading = driver.find_element(By.CSS_SELECTOR, ".hero-text h1")
        assert "Premium" in heading.text, "Hero heading should contain 'Premium'"

        shop_btn = driver.find_element(By.CSS_SELECTOR, ".hero-buttons a.btn-primary")
        assert shop_btn.is_displayed(), "'Shop Now' button should be visible"

    # ATC-008: Verify "Shop Now" button navigates to Products
    def test_atc008_shop_now_button(self, driver):
        """ATC-008: 'Shop Now' should navigate to the products page."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        shop_btn = driver.find_element(By.CSS_SELECTOR, ".hero-buttons a.btn-primary")
        shop_btn.click()
        wait_for_page_load(driver)

        assert "products" in driver.current_url.lower(), \
            "'Shop Now' should navigate to products page"

    # ATC-009: Verify brand logos section exists
    def test_atc009_brands_section(self, driver):
        """ATC-009: Brands section should display partner brand names."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        brands = driver.find_elements(By.CSS_SELECTOR, ".brand-item")
        assert len(brands) >= 5, f"Should have at least 5 brands, found {len(brands)}"

        brand_names = [b.text for b in brands]
        assert "NexGen" in brand_names, "NexGen should be a listed brand"

    # ATC-010: Verify category cards exist and are clickable
    def test_atc010_category_cards(self, driver):
        """ATC-010: All 4 category cards should be visible and clickable."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        categories = driver.find_elements(By.CSS_SELECTOR, ".category-card")
        assert len(categories) == 4, f"Should have 4 category cards, found {len(categories)}"

        category_texts = [c.text for c in categories]
        combined = " ".join(category_texts)
        assert "Audio" in combined, "Audio category should exist"
        assert "Computers" in combined, "Computers category should exist"
        assert "Gaming" in combined, "Gaming category should exist"


# ═══════════════════════════════════════════════════════════
# ATC-011 to ATC-018: PRODUCT LISTING & FILTERING
# ═══════════════════════════════════════════════════════════

class TestProductListingFiltering:
    """ATC-011 to ATC-018: Product Listing & Filtering Tests"""

    # ATC-011: Verify all products are displayed
    def test_atc011_all_products_displayed(self, driver):
        """ATC-011: Products page should display all products."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "#catalogProducts .product-card"))
        )
        products = driver.find_elements(By.CSS_SELECTOR, "#catalogProducts .product-card")
        assert len(products) >= 10, f"Should have at least 10 products, found {len(products)}"

    # ATC-012: Verify product count display
    def test_atc012_product_count_display(self, driver):
        """ATC-012: Product count indicator should show correct number."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)
        time.sleep(1)

        count_el = driver.find_element(By.ID, "productCount")
        count = int(count_el.text)
        assert count > 0, "Product count should be greater than 0"

    # ATC-013: Verify category filter — Audio
    def test_atc013_category_filter_audio(self, driver):
        """ATC-013: Clicking Audio filter should show only Audio products."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)
        time.sleep(1)

        audio_filter = driver.find_element(By.CSS_SELECTOR, "[data-category='Audio']")
        audio_filter.click()
        time.sleep(1)

        count_el = driver.find_element(By.ID, "productCount")
        count = int(count_el.text)
        assert count <= 5, f"Audio filter should show fewer products, got {count}"

    # ATC-014: Verify sort by Price Low to High
    def test_atc014_sort_price_low_to_high(self, driver):
        """ATC-014: Sorting by 'Price: Low to High' should reorder products."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)
        time.sleep(1)

        sort_select = Select(driver.find_element(By.ID, "sortSelect"))
        sort_select.select_by_value("price-low")
        time.sleep(1)

        # Products should now be sorted — verify the select changed
        selected = sort_select.first_selected_option
        assert selected.get_attribute("value") == "price-low", \
            "Sort dropdown should be set to 'price-low'"

    # ATC-015: Verify sort by Price High to Low
    def test_atc015_sort_price_high_to_low(self, driver):
        """ATC-015: Sorting by 'Price: High to Low' should reorder products."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)
        time.sleep(1)

        sort_select = Select(driver.find_element(By.ID, "sortSelect"))
        sort_select.select_by_value("price-high")
        time.sleep(1)

        selected = sort_select.first_selected_option
        assert selected.get_attribute("value") == "price-high", \
            "Sort dropdown should be set to 'price-high'"

    # ATC-016: Verify sort by Highest Rated
    def test_atc016_sort_highest_rated(self, driver):
        """ATC-016: Sorting by 'Highest Rated' should reorder products."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)
        time.sleep(1)

        sort_select = Select(driver.find_element(By.ID, "sortSelect"))
        sort_select.select_by_value("rating")
        time.sleep(1)

        selected = sort_select.first_selected_option
        assert selected.get_attribute("value") == "rating", \
            "Sort dropdown should be set to 'rating'"

    # ATC-017: Verify price range slider exists and is functional
    def test_atc017_price_range_slider(self, driver):
        """ATC-017: Price range slider should exist and have correct range."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)

        slider = driver.find_element(By.ID, "priceRange")
        assert slider.is_displayed(), "Price range slider should be visible"

        min_val = slider.get_attribute("min")
        max_val = slider.get_attribute("max")
        assert min_val == "0", f"Slider min should be 0, got {min_val}"
        assert max_val == "3000", f"Slider max should be 3000, got {max_val}"

    # ATC-018: Verify catalog search input on products page
    def test_atc018_catalog_search_input(self, driver):
        """ATC-018: Catalog search input on products page should filter products."""
        driver.get(f"{BASE_URL}/products.html")
        wait_for_page_load(driver)
        time.sleep(1)

        search_input = driver.find_element(By.ID, "catalogSearch")
        assert search_input.is_displayed(), "Catalog search should be visible"

        search_input.send_keys("headphone")
        time.sleep(1)

        count_el = driver.find_element(By.ID, "productCount")
        count = int(count_el.text)
        assert count >= 1, "Search should return at least 1 result for 'headphone'"


# ═══════════════════════════════════════════════════════════
# ATC-019 to ATC-024: PRODUCT SEARCH (Modal)
# ═══════════════════════════════════════════════════════════

class TestProductSearch:
    """ATC-019 to ATC-024: Product Search Modal Tests"""

    # ATC-019: Verify search modal opens
    def test_atc019_search_modal_opens(self, driver):
        """ATC-019: Clicking search icon should open the search modal."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        search_btn = driver.find_element(By.ID, "searchBtn")
        search_btn.click()
        time.sleep(0.5)

        modal = driver.find_element(By.ID, "searchModal")
        assert "active" in modal.get_attribute("class"), \
            "Search modal should have 'active' class after clicking search icon"

    # ATC-020: Verify search returns results for valid query
    def test_atc020_search_valid_query(self, driver):
        """ATC-020: Searching 'headphones' should return matching products."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        search_btn = driver.find_element(By.ID, "searchBtn")
        search_btn.click()
        time.sleep(0.5)

        search_input = driver.find_element(By.CSS_SELECTOR, ".search-modal-input")
        search_input.send_keys("headphones")
        time.sleep(1)

        results = driver.find_elements(By.CSS_SELECTOR, ".search-result-item")
        assert len(results) >= 1, "Search for 'headphones' should return at least 1 result"

    # ATC-021: Verify search with category name
    def test_atc021_search_by_category(self, driver):
        """ATC-021: Searching 'gaming' should return Gaming category products."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        search_btn = driver.find_element(By.ID, "searchBtn")
        search_btn.click()
        time.sleep(0.5)

        search_input = driver.find_element(By.CSS_SELECTOR, ".search-modal-input")
        search_input.send_keys("gaming")
        time.sleep(1)

        results = driver.find_elements(By.CSS_SELECTOR, ".search-result-item")
        assert len(results) >= 1, "Search for 'gaming' should return results"

    # ATC-022: Verify search with less than 2 characters (boundary)
    def test_atc022_search_single_char(self, driver):
        """ATC-022: Single character search should not return results (boundary)."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        search_btn = driver.find_element(By.ID, "searchBtn")
        search_btn.click()
        time.sleep(0.5)

        search_input = driver.find_element(By.CSS_SELECTOR, ".search-modal-input")
        search_input.send_keys("a")
        time.sleep(1)

        results = driver.find_elements(By.CSS_SELECTOR, ".search-result-item")
        assert len(results) == 0, "Single char search should return no results"

    # ATC-023: Verify search with non-matching query (negative)
    def test_atc023_search_no_match(self, driver):
        """ATC-023: Non-matching query should return zero results."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        search_btn = driver.find_element(By.ID, "searchBtn")
        search_btn.click()
        time.sleep(0.5)

        search_input = driver.find_element(By.CSS_SELECTOR, ".search-modal-input")
        search_input.send_keys("xyznonexistent123")
        time.sleep(1)

        results = driver.find_elements(By.CSS_SELECTOR, ".search-result-item")
        assert len(results) == 0, "Non-matching query should return no results"

    # ATC-024: Verify search modal closes with Escape key
    def test_atc024_search_modal_close_escape(self, driver):
        """ATC-024: Pressing Escape should close the search modal."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        search_btn = driver.find_element(By.ID, "searchBtn")
        search_btn.click()
        time.sleep(0.5)

        modal = driver.find_element(By.ID, "searchModal")
        assert "active" in modal.get_attribute("class"), "Modal should be open"

        body = driver.find_element(By.TAG_NAME, "body")
        body.send_keys(Keys.ESCAPE)
        time.sleep(0.5)

        modal_class = modal.get_attribute("class")
        assert "active" not in modal_class, \
            "Search modal should close after pressing Escape"


# ═══════════════════════════════════════════════════════════
# ATC-025 to ATC-029: PRODUCT DETAILS
# ═══════════════════════════════════════════════════════════

class TestProductDetails:
    """ATC-025 to ATC-029: Product Detail Page Tests"""

    # ATC-025: Verify product detail page loads
    def test_atc025_product_detail_loads(self, driver):
        """ATC-025: Product detail page should load with product info."""
        driver.get(f"{BASE_URL}/product-detail.html?id=1")
        wait_for_page_load(driver)
        time.sleep(2)

        product_info = driver.find_element(By.ID, "productInfo")
        assert product_info.text != "", "Product info section should have content"

    # ATC-026: Verify breadcrumb navigation on product detail
    def test_atc026_breadcrumb_navigation(self, driver):
        """ATC-026: Breadcrumb should show Home > Products > Product Name."""
        driver.get(f"{BASE_URL}/product-detail.html?id=1")
        wait_for_page_load(driver)
        time.sleep(2)

        breadcrumbs = driver.find_element(By.ID, "breadcrumbs")
        assert breadcrumbs.is_displayed(), "Breadcrumbs should be visible"

        links = breadcrumbs.find_elements(By.TAG_NAME, "a")
        assert len(links) >= 2, "Breadcrumb should have at least Home and Products links"

    # ATC-027: Verify related products section
    def test_atc027_related_products(self, driver):
        """ATC-027: Related products section should display on product detail."""
        driver.get(f"{BASE_URL}/product-detail.html?id=1")
        wait_for_page_load(driver)
        time.sleep(2)

        related_heading = driver.find_element(By.CSS_SELECTOR, ".related-products h2")
        assert "Also Like" in related_heading.text or "Related" in related_heading.text, \
            "Related products heading should exist"

    # ATC-028: Verify product detail with invalid ID (negative)
    def test_atc028_invalid_product_id(self, driver):
        """ATC-028: Invalid product ID should not crash the page."""
        driver.get(f"{BASE_URL}/product-detail.html?id=9999")
        wait_for_page_load(driver)
        time.sleep(2)

        # Page should still be loaded (not a 404/crash)
        assert "NovaTech" in driver.title or "Product" in driver.title, \
            "Page should still load even with invalid product ID"

    # ATC-029: Verify product detail with no ID parameter (boundary)
    def test_atc029_no_product_id(self, driver):
        """ATC-029: No product ID should handle gracefully."""
        driver.get(f"{BASE_URL}/product-detail.html")
        wait_for_page_load(driver)
        time.sleep(2)

        # Page should load without crashing
        body_text = driver.find_element(By.TAG_NAME, "body").text
        assert len(body_text) > 0, "Page should render some content even without product ID"


# ═══════════════════════════════════════════════════════════
# ATC-030 to ATC-037: SHOPPING CART
# ═══════════════════════════════════════════════════════════

class TestShoppingCart:
    """ATC-030 to ATC-037: Shopping Cart Tests"""

    # ATC-030: Verify adding a product to cart
    def test_atc030_add_product_to_cart(self, driver):
        """ATC-030: Adding a product should update cart count."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        # Clear cart first
        driver.execute_script("localStorage.removeItem('luxe_cart');")
        driver.refresh()
        wait_for_page_load(driver)

        # Add product via JS
        add_product_to_cart_via_js(driver, 1)

        cart_count = driver.find_element(By.ID, "cartCount")
        assert cart_count.text == "1", f"Cart count should be 1, got {cart_count.text}"

    # ATC-031: Verify cart count updates for multiple products
    def test_atc031_cart_count_multiple(self, driver):
        """ATC-031: Adding multiple products should update cart count."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        driver.execute_script("localStorage.removeItem('luxe_cart');")
        driver.refresh()
        wait_for_page_load(driver)

        add_product_to_cart_via_js(driver, 1)
        add_product_to_cart_via_js(driver, 2)

        cart_count = driver.find_element(By.ID, "cartCount")
        count = int(cart_count.text)
        assert count == 2, f"Cart count should be 2, got {count}"

    # ATC-032: Verify adding same product increments quantity
    def test_atc032_add_same_product_twice(self, driver):
        """ATC-032: Adding same product twice should increment qty not duplicate."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        driver.execute_script("localStorage.removeItem('luxe_cart');")
        driver.refresh()
        wait_for_page_load(driver)

        add_product_to_cart_via_js(driver, 1)
        add_product_to_cart_via_js(driver, 1)

        cart_count = driver.find_element(By.ID, "cartCount")
        assert cart_count.text == "2", "Cart count should be 2 after adding same product twice"

        # Verify only 1 unique item in cart
        cart_items = driver.execute_script("return CartManager.getCart().length;")
        assert cart_items == 1, "Cart should have 1 unique item"

    # ATC-033: Verify cart total calculation
    def test_atc033_cart_total_calculation(self, driver):
        """ATC-033: Cart total should correctly sum item prices."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        driver.execute_script("localStorage.removeItem('luxe_cart');")
        driver.refresh()
        wait_for_page_load(driver)

        add_product_to_cart_via_js(driver, 1)

        total = driver.execute_script("return CartManager.getTotal();")
        assert total > 0, f"Cart total should be > 0, got {total}"

    # ATC-034: Verify removing item from cart
    def test_atc034_remove_item_from_cart(self, driver):
        """ATC-034: Removing an item should update cart count to 0."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        driver.execute_script("localStorage.removeItem('luxe_cart');")
        driver.refresh()
        wait_for_page_load(driver)

        add_product_to_cart_via_js(driver, 1)
        cart_count = driver.find_element(By.ID, "cartCount")
        assert cart_count.text == "1", "Cart count should be 1"

        # Remove via JS
        driver.execute_script("CartManager.removeItem(1);")
        time.sleep(0.5)

        count = driver.execute_script("return CartManager.getCount();")
        assert count == 0, f"Cart count should be 0 after removal, got {count}"

    # ATC-035: Verify cart persists after page refresh (localStorage)
    def test_atc035_cart_persistence(self, driver):
        """ATC-035: Cart should persist across page refreshes."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        driver.execute_script("localStorage.removeItem('luxe_cart');")
        driver.refresh()
        wait_for_page_load(driver)

        add_product_to_cart_via_js(driver, 1)

        # Refresh the page
        driver.refresh()
        wait_for_page_load(driver)

        cart_data = driver.execute_script("return CartManager.getCart();")
        assert len(cart_data) == 1, "Cart should persist 1 item after refresh"

    # ATC-036: Verify clear cart functionality
    def test_atc036_clear_cart(self, driver):
        """ATC-036: Clearing cart should remove all items."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        add_product_to_cart_via_js(driver, 1)
        add_product_to_cart_via_js(driver, 2)

        driver.execute_script("CartManager.clear();")
        time.sleep(0.5)

        count = driver.execute_script("return CartManager.getCount();")
        assert count == 0, f"Cart should be empty after clear, got {count}"

    # ATC-037: Verify cart page navigation
    def test_atc037_cart_page_navigation(self, driver):
        """ATC-037: Clicking cart icon should navigate to cart page."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        cart_btn = driver.find_element(By.CSS_SELECTOR, "a.nav-cart-btn")
        cart_btn.click()
        wait_for_page_load(driver)

        assert "cart" in driver.current_url.lower(), \
            "Should navigate to cart page"


# ═══════════════════════════════════════════════════════════
# ATC-038 to ATC-043: CONTACT FORM
# ═══════════════════════════════════════════════════════════

class TestContactForm:
    """ATC-038 to ATC-043: Contact Form Tests"""

    # ATC-038: Verify contact form loads with all fields
    def test_atc038_contact_form_loads(self, driver):
        """ATC-038: Contact form should have all required fields."""
        driver.get(f"{BASE_URL}/contact.html")
        wait_for_page_load(driver)

        first_name = driver.find_element(By.ID, "firstName")
        last_name = driver.find_element(By.ID, "lastName")
        email = driver.find_element(By.ID, "email")
        subject = driver.find_element(By.ID, "subject")
        message = driver.find_element(By.ID, "message")

        assert first_name.is_displayed(), "First Name field should be visible"
        assert last_name.is_displayed(), "Last Name field should be visible"
        assert email.is_displayed(), "Email field should be visible"
        assert subject.is_displayed(), "Subject dropdown should be visible"
        assert message.is_displayed(), "Message textarea should be visible"

    # ATC-039: Verify successful contact form submission
    def test_atc039_contact_form_submit_valid(self, driver):
        """ATC-039: Valid form data should submit and show success toast."""
        driver.get(f"{BASE_URL}/contact.html")
        wait_for_page_load(driver)

        driver.find_element(By.ID, "firstName").send_keys("John")
        driver.find_element(By.ID, "lastName").send_keys("Doe")
        driver.find_element(By.ID, "email").send_keys("john@example.com")

        subject_select = Select(driver.find_element(By.ID, "subject"))
        subject_select.select_by_value("product")

        driver.find_element(By.ID, "message").send_keys(
            "Is the AuraWave Pro available in blue?"
        )

        submit_btn = driver.find_element(By.CSS_SELECTOR, "#contactForm button[type='submit']")
        submit_btn.click()
        time.sleep(1)

        # Check for toast notification
        toast = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".toast-success, .toast"))
        )
        assert toast.is_displayed(), "Success toast should appear"

    # ATC-040: Verify contact form — empty first name validation (negative)
    def test_atc040_contact_form_empty_firstname(self, driver):
        """ATC-040: Submitting with empty first name should trigger validation."""
        driver.get(f"{BASE_URL}/contact.html")
        wait_for_page_load(driver)

        # Fill everything except first name
        driver.find_element(By.ID, "lastName").send_keys("Doe")
        driver.find_element(By.ID, "email").send_keys("john@example.com")
        Select(driver.find_element(By.ID, "subject")).select_by_value("other")
        driver.find_element(By.ID, "message").send_keys("Test message")

        submit_btn = driver.find_element(By.CSS_SELECTOR, "#contactForm button[type='submit']")
        submit_btn.click()
        time.sleep(0.5)

        # First name should have validation error (required)
        first_name = driver.find_element(By.ID, "firstName")
        is_valid = driver.execute_script(
            "return arguments[0].checkValidity();", first_name
        )
        assert not is_valid, "First Name should fail validation when empty"

    # ATC-041: Verify contact form — invalid email validation (negative)
    def test_atc041_contact_form_invalid_email(self, driver):
        """ATC-041: Invalid email should fail validation."""
        driver.get(f"{BASE_URL}/contact.html")
        wait_for_page_load(driver)

        driver.find_element(By.ID, "firstName").send_keys("John")
        driver.find_element(By.ID, "lastName").send_keys("Doe")
        driver.find_element(By.ID, "email").send_keys("invalid-email")
        Select(driver.find_element(By.ID, "subject")).select_by_value("other")
        driver.find_element(By.ID, "message").send_keys("Test")

        email_field = driver.find_element(By.ID, "email")
        is_valid = driver.execute_script(
            "return arguments[0].checkValidity();", email_field
        )
        assert not is_valid, "Invalid email should fail HTML5 validation"

    # ATC-042: Verify subject dropdown options
    def test_atc042_subject_dropdown_options(self, driver):
        """ATC-042: Subject dropdown should have all expected options."""
        driver.get(f"{BASE_URL}/contact.html")
        wait_for_page_load(driver)

        subject_select = Select(driver.find_element(By.ID, "subject"))
        options = [opt.text for opt in subject_select.options]

        assert "Order Inquiry" in options, "'Order Inquiry' should be an option"
        assert "Product Question" in options, "'Product Question' should be an option"
        assert "Returns & Refunds" in options, "'Returns & Refunds' should be an option"
        assert "Technical Support" in options, "'Technical Support' should be an option"
        assert "Other" in options, "'Other' should be an option"

    # ATC-043: Verify contact form resets after submission
    def test_atc043_contact_form_resets(self, driver):
        """ATC-043: Form should reset to empty after successful submission."""
        driver.get(f"{BASE_URL}/contact.html")
        wait_for_page_load(driver)

        driver.find_element(By.ID, "firstName").send_keys("Test")
        driver.find_element(By.ID, "lastName").send_keys("User")
        driver.find_element(By.ID, "email").send_keys("test@test.com")
        Select(driver.find_element(By.ID, "subject")).select_by_value("other")
        driver.find_element(By.ID, "message").send_keys("Hello")

        submit_btn = driver.find_element(By.CSS_SELECTOR, "#contactForm button[type='submit']")
        submit_btn.click()
        time.sleep(1)

        # After submission, fields should be cleared
        first_name_val = driver.find_element(By.ID, "firstName").get_attribute("value")
        assert first_name_val == "", "First Name should be empty after form reset"


# ═══════════════════════════════════════════════════════════
# ATC-044 to ATC-046: NEWSLETTER SUBSCRIPTION
# ═══════════════════════════════════════════════════════════

class TestNewsletterSubscription:
    """ATC-044 to ATC-046: Newsletter Subscription Tests"""

    # ATC-044: Verify newsletter subscription with valid email
    def test_atc044_newsletter_valid_email(self, driver):
        """ATC-044: Valid email should show success toast on subscription."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        # Scroll to newsletter section
        newsletter = driver.find_element(By.ID, "newsletter")
        driver.execute_script("arguments[0].scrollIntoView(true);", newsletter)
        time.sleep(1)

        email_input = driver.find_element(By.CSS_SELECTOR, ".newsletter-form input[type='email']")
        email_input.send_keys("test@example.com")

        submit_btn = driver.find_element(By.CSS_SELECTOR, ".newsletter-form button[type='submit']")
        submit_btn.click()
        time.sleep(1)

        toast = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".toast"))
        )
        assert "subscribing" in toast.text.lower() or "thanks" in toast.text.lower(), \
            "Toast should show subscription success"

    # ATC-045: Verify newsletter with invalid email (negative)
    def test_atc045_newsletter_invalid_email(self, driver):
        """ATC-045: Invalid email should fail HTML5 validation."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        newsletter = driver.find_element(By.ID, "newsletter")
        driver.execute_script("arguments[0].scrollIntoView(true);", newsletter)
        time.sleep(1)

        email_input = driver.find_element(By.CSS_SELECTOR, ".newsletter-form input[type='email']")
        email_input.send_keys("not-an-email")

        is_valid = driver.execute_script(
            "return arguments[0].checkValidity();", email_input
        )
        assert not is_valid, "Invalid email should fail HTML5 validation"

    # ATC-046: Verify newsletter with empty email (negative)
    def test_atc046_newsletter_empty_email(self, driver):
        """ATC-046: Empty email should fail required field validation."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        newsletter = driver.find_element(By.ID, "newsletter")
        driver.execute_script("arguments[0].scrollIntoView(true);", newsletter)
        time.sleep(1)

        email_input = driver.find_element(By.CSS_SELECTOR, ".newsletter-form input[type='email']")
        # Don't type anything

        is_valid = driver.execute_script(
            "return arguments[0].checkValidity();", email_input
        )
        assert not is_valid, "Empty required email should fail validation"


# ═══════════════════════════════════════════════════════════
# ATC-047 to ATC-050: RESPONSIVE DESIGN, UI & SEO
# ═══════════════════════════════════════════════════════════

class TestResponsiveUISEO:
    """ATC-047 to ATC-050: Responsive Design, UI & SEO Tests"""

    # ATC-047: Verify hamburger menu is visible on mobile viewport
    def test_atc047_hamburger_menu_mobile(self, driver):
        """ATC-047: Hamburger menu should be visible at mobile width."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        # Resize to mobile
        driver.set_window_size(375, 812)
        time.sleep(1)

        hamburger = driver.find_element(By.ID, "navHamburger")
        assert hamburger.is_displayed(), "Hamburger menu should be visible on mobile"

        # Reset
        driver.maximize_window()

    # ATC-048: Verify page title and meta description for SEO
    def test_atc048_seo_meta_tags(self, driver):
        """ATC-048: Homepage should have proper SEO meta tags."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        title = driver.title
        assert len(title) > 10, f"Title should be descriptive, got: '{title}'"
        assert "NovaTech" in title, "Title should contain 'NovaTech'"

        meta_desc = driver.find_element(By.CSS_SELECTOR, "meta[name='description']")
        content = meta_desc.get_attribute("content")
        assert len(content) > 50, f"Meta description should be descriptive, got: '{content}'"

    # ATC-049: Verify footer content and links
    def test_atc049_footer_content(self, driver):
        """ATC-049: Footer should have brand info, links, and copyright."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        footer = driver.find_element(By.CSS_SELECTOR, "footer.footer")
        assert footer.is_displayed(), "Footer should be visible"

        footer_columns = driver.find_elements(By.CSS_SELECTOR, ".footer-column")
        assert len(footer_columns) >= 3, f"Footer should have at least 3 columns, found {len(footer_columns)}"

        copyright_text = driver.find_element(By.CSS_SELECTOR, ".footer-bottom p")
        assert "2024" in copyright_text.text or "NovaTech" in copyright_text.text, \
            "Copyright text should mention year or brand"

    # ATC-050: Verify social media links in footer
    def test_atc050_social_media_links(self, driver):
        """ATC-050: Footer should have social media links with aria-labels."""
        driver.get(BASE_URL)
        wait_for_page_load(driver)

        social_links = driver.find_elements(By.CSS_SELECTOR, ".footer-social a")
        assert len(social_links) == 4, f"Should have 4 social links, found {len(social_links)}"

        # Verify aria-labels exist for accessibility
        for link in social_links:
            aria_label = link.get_attribute("aria-label")
            assert aria_label is not None and len(aria_label) > 0, \
                f"Social link should have aria-label, got: {aria_label}"


# ═══════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--html=test_report.html", "--self-contained-html"])
