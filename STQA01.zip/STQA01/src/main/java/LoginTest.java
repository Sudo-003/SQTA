import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LoginTest {

    public static void main(String[] args) throws InterruptedException {

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        WebDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/");
        Thread.sleep(3000);

        WebElement username = driver.findElement(By.id("username"));
        username.clear();
        username.sendKeys("student");

        WebElement password = driver.findElement(By.id("password"));
        password.clear();
        password.sendKeys("Password123");

        WebElement loginBtn = driver.findElement(By.id("submit"));
        loginBtn.click();
        Thread.sleep(3000);

        String url = driver.getCurrentUrl();
        System.out.println("URL: " + url);

        if (url.contains("logged-in-successfully")) {
            System.out.println("TEST PASSED: Login Successful!");
        } else {
            System.out.println("TEST FAILED: Login Failed!");
        }

        driver.quit();
    }
}
