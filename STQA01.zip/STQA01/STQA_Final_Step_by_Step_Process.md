# 📋 STQA Practical Exam — Master Step-by-Step Guide

---

# Part 1️⃣ — Manual Testing: Test Case Writing

## Step 1: The Standard 6-Column Test Case Format
In your answer sheet, lab journal, or Word document, draw this exact table:

| Test Case ID | Test Scenario | Test Steps | Test Data | Expected Result | Status |
|:---|:---|:---|:---|:---|:---:|
| `TC_MOD_001` | *Brief description of what is being tested* | 1. Step one<br>2. Step two<br>3. Click action button | *Exact data used* | *What system should do* | Pass / Fail |

---

## Step 2: The 10-Case Formula (Universal Recipe)
For **any** feature given by the examiner (Login, Registration, Search, Cart):
1. **Positive Cases (2):** Valid inputs $\rightarrow$ successful operation.
2. **Negative Cases (4):** Wrong password, wrong username, empty required fields.
3. **Boundary / Edge Cases (2):** Extreme length, special characters, SQL injection.
4. **UI & Security Cases (2):** Password masked (`•••••`), layout elements visible.

---

## Step 3: Complete Ready-to-Use Worked Example: Login Page

| Test Case ID | Test Scenario | Test Steps | Test Data | Expected Result | Status |
|:---|:---|:---|:---|:---|:---:|
| **TC_LOGIN_001** | Verify login with valid credentials | 1. Open login URL<br>2. Enter valid username<br>3. Enter valid password<br>4. Click 'Login' | User: `student`<br>Pass: `Password123` | Redirected to dashboard/home page with success message | Pass |
| **TC_LOGIN_002** | Verify login with invalid password | 1. Enter valid username<br>2. Enter incorrect password<br>3. Click 'Login' | User: `student`<br>Pass: `wrongpass` | Error message "Invalid username or password" displayed | Pass |
| **TC_LOGIN_003** | Verify login with invalid username | 1. Enter non-existent username<br>2. Enter valid password<br>3. Click 'Login' | User: `unknown_user`<br>Pass: `Password123` | Error message "Invalid username or password" displayed | Pass |
| **TC_LOGIN_004** | Verify login with empty username | 1. Leave username field blank<br>2. Enter valid password<br>3. Click 'Login' | User: *(empty)*<br>Pass: `Password123` | Validation message "Username is required" displayed | Pass |
| **TC_LOGIN_005** | Verify login with empty password | 1. Enter valid username<br>2. Leave password field blank<br>3. Click 'Login' | User: `student`<br>Pass: *(empty)* | Validation message "Password is required" displayed | Pass |
| **TC_LOGIN_006** | Verify login with both fields empty | 1. Leave both fields blank<br>2. Click 'Login' | User: *(empty)*<br>Pass: *(empty)* | Validation messages for both required fields displayed | Pass |
| **TC_LOGIN_007** | Verify password masking | 1. Type in password field | Pass: `Password123` | Characters must display as bullets/dots (`•••••`) | Pass |
| **TC_LOGIN_008** | Verify SQL Injection security | 1. Enter SQL injection payload in username<br>2. Enter any password<br>3. Click 'Login' | User: `' OR 1=1 --`<br>Pass: `admin` | Login fails gracefully without database error or crash | Pass |
| **TC_LOGIN_009** | Verify Forgot Password link | 1. Click on "Forgot Password" link | — | User is redirected to password recovery page | Pass |
| **TC_LOGIN_010** | Verify Login page UI elements | 1. Open the login page | — | Logo, fields, placeholders, and buttons are visible & aligned | Pass |

---
---

# Part 2️⃣ — Automation Testing: Selenium WebDriver

## Step 1: Project Structure & Setup

Ensure files are placed in standard directories:
```
STQA01/
├── pom.xml                     # Maven dependencies (if using Maven)
├── lib/                        # Selenium JAR files (if manual Build Path)
├── src/
│   └── main/
│       └── java/
│           └── LoginTest.java  # Selenium Test Script
└── target/                     # Compiled .class files
```

> **Crucial Rule:** In Java/Maven, `src/main/java` is the **Source Folder**.
> Never place a `.java` file in the root folder or add `package src.main.java;`. Keep classes directly in `src/main/java` under the default package or standard package name.

---

## Step 2: Complete Automation Script (`LoginTest.java`)

```java
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LoginTest {

    public static void main(String[] args) throws InterruptedException {

        // STEP 1: Configure Chrome Driver
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        WebDriver driver = new ChromeDriver(options);

        // STEP 2: Maximize Window & Navigate to Web Page
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/");
        Thread.sleep(2000); // Wait for page to render

        // STEP 3: Locate Username Field & Enter Text
        WebElement username = driver.findElement(By.id("username"));
        username.clear();
        username.sendKeys("student");

        // STEP 4: Locate Password Field & Enter Text
        WebElement password = driver.findElement(By.id("password"));
        password.clear();
        password.sendKeys("Password123");

        // STEP 5: Click Submit Button
        WebElement loginBtn = driver.findElement(By.id("submit"));
        loginBtn.click();
        Thread.sleep(2000); // Wait for redirect

        // STEP 6: Assert Result (Expected vs Actual)
        String currentUrl = driver.getCurrentUrl();
        System.out.println("Navigated URL: " + currentUrl);

        if (currentUrl.contains("logged-in-successfully")) {
            System.out.println("=================================");
            System.out.println("  TEST PASSED: Login Successful! ");
            System.out.println("=================================");
        } else {
            System.out.println("=================================");
            System.out.println("  TEST FAILED: Login Failed!     ");
            System.out.println("=================================");
        }

        // STEP 7: Close Browser
        driver.quit();
    }
}
```

---

## Step 3: How to Execute

### Option A: In Eclipse IDE
1. Open [`LoginTest.java`](file:///d:/STQA01/src/main/java/LoginTest.java).
2. Right-click anywhere in the editor $\rightarrow$ **Run As** $\rightarrow$ **Java Application** (or press <kbd>Alt</kbd> + <kbd>Shift</kbd> + <kbd>X</kbd>, then <kbd>J</kbd>).
3. Chrome will automatically launch, perform the actions, and print `TEST PASSED` in the Console window.

### Option B: Via Terminal / Command Line
Run this command from your project root:
```powershell
java -cp "target/classes;lib/*" LoginTest
```

---
---

# Part 3️⃣ — How to Solve Common Exam Errors

### 1. `The declared package "" does not match expected package "src.main.java"`
* **Cause:** The IDE is treating the project root as the source folder instead of `src/main/java`.
* **Fix in Eclipse:** Right-click folder `src/main/java` $\rightarrow$ **Build Path** $\rightarrow$ **Use as Source Folder**.
* **Fix in Maven:** Right-click project $\rightarrow$ **Maven** $\rightarrow$ **Update Project...** (<kbd>Alt</kbd> + <kbd>F5</kbd>) $\rightarrow$ Click **OK**.

### 2. `NoSuchElementException: Unable to find element with id...`
* **Cause:** Element ID is misspelled, or the page hasn't finished loading.
* **Fix:** Add `Thread.sleep(2000);` before finding the element, or re-inspect the element in Chrome Developer Tools (<kbd>F12</kbd>).

---
---

# Part 4️⃣ — Quick Viva / Oral Questions Cheat Sheet

| Question | Clear & Concise Answer |
|:---|:---|
| **What is Selenium WebDriver?** | WebDriver is a browser automation tool that executes commands directly through the browser's native engine. |
| **Difference between `close()` and `quit()`?** | `close()` closes only the active tab; `quit()` closes all browser windows and shuts down the ChromeDriver process. |
| **What locators are supported?** | `By.id()`, `By.name()`, `By.className()`, `By.xpath()`, `By.cssSelector()`, `By.linkText()`, and `By.tagName()`. |
| **Why use `clear()` before `sendKeys()`?** | To ensure any pre-filled or placeholder text inside the input box is wiped clean before typing new text. |
| **Difference between Verification and Validation?** | Verification checks *“Are we building the product right?”* (Code reviews, static checks). Validation checks *“Are we building the right product?”* (Executing software against user requirements). |
